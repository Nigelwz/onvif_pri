var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "g", "globals_g.html", null ],
    [ "m", "globals_m.html", null ],
    [ "n", "globals_n.html", null ],
    [ "s", "globals_s.html", null ],
    [ "u", "globals_u.html", null ]
];