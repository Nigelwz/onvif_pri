var structsoap__mime =
[
    [ "begin", "structsoap__mime.html#ae99fa19c5d24051a495b79a024a3f5f9", null ],
    [ "end", "structsoap__mime.html#af810e927cdbe61242f978918fc2de748", null ],
    [ "list", "structsoap__mime.html#aeef725035ddedf24b29d1070e0f9bb33", null ]
];