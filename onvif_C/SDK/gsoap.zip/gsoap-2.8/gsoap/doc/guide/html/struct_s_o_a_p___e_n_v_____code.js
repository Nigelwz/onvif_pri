var struct_s_o_a_p___e_n_v_____code =
[
    [ "SOAP_ENV__Subcode", "struct_s_o_a_p___e_n_v_____code.html#a2d44ac860b79956cff26131fa68b4c5a", null ],
    [ "SOAP_ENV__Value", "struct_s_o_a_p___e_n_v_____code.html#a6285b1ed8b2cadc318d730f9715b2958", null ]
];